/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package office.Controller;

import Database.DbConnection;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import office.Entities.Period;
import office.Entities.Student;

/**
 *
 * @author Omar Ahmed
 */
public class StudentController {
    
    public Student GetStudentData(int id){
        Student student=new Student();
        
        DbConnection dbConnection=new DbConnection();
        
        try {
            student=dbConnection.selecBytId(id);
            if(student==null){
                student=new Student();
                student.setId(-1);
            }
            
            
        } catch (Exception ex) {
            
            Logger.getLogger(StudentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return student;
    }
    
    
    public ArrayList<Student> GetStudentAttendence(int SId){
        DbConnection dbConnection=new DbConnection();
        ArrayList<Student> Attendences  = new ArrayList<>();
        
        try {
            Attendences=dbConnection.selecAttendance(SId);
        } catch (Exception ex) {
            Logger.getLogger(StudentController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return Attendences;
    }
    
    
    public boolean InsertStudentAttendence(int SId,int gpNum, int pe,int Attendgroup){
        DbConnection dbConnection=new DbConnection();
        Period period=new Period(pe);
        Student student=new Student(SId, gpNum, period);
        
        
        return dbConnection.insertAttendence(student, Attendgroup);
        
    }
    
    public boolean InsertExam(Student student){
        int check=0;
        DbConnection dbConnection =new DbConnection();
        try {
            
            check=dbConnection.updateAttendence(student);
            if(check==0)
                return false;
            else            
                return true;
        } catch (Exception ex) {
            return false;
        }
        
    }
}
