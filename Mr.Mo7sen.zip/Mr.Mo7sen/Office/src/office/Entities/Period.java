/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package office.Entities;

/**
 *
 * @author Omar Ahmed
 */
public class Period {
    int GroupNumber , AttendenceNumber, Absence, AttendInAnotherTime,id,TotalNumber,totalDegree;
    String Date,Notes;
    double payment,increaseBalance,TotalMoney,studentDegree;
    
    public Period(int GroupNumber, int AttendenceNumber, int Absence, int AttendInAnotherTime, double TotalMoney, int id, int totalNumber, String Date, String notes, double payment,double increase) {
        this.GroupNumber = GroupNumber;
        this.AttendenceNumber = AttendenceNumber;
        this.Absence = Absence;
        this.AttendInAnotherTime = AttendInAnotherTime;
        this.TotalMoney = TotalMoney;
        this.id = id;
        this.TotalNumber = totalNumber;
        this.Date = Date;
        this.Notes = notes;
        this.payment = payment;
        this.increaseBalance =increase;
    }

    public Period() {
    }


    
    public Period(int id) {
        this.id = id;
    }
    public Period(int id,int total,double sdegree) {
        this.id=id;
        this.totalDegree =total;
        this.studentDegree= sdegree;
    }
    public int getGroupNumber() {
        return GroupNumber;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setGroupNumber(int GroupNumber) {
        this.GroupNumber = GroupNumber;
    }

    public int getAttendenceNumber() {
        return AttendenceNumber;
    }

    public void setAttendenceNumber(int AttendenceNumber) {
        this.AttendenceNumber = AttendenceNumber;
    }

    public int getAbsence() {
        return Absence;
    }

    public void setAbsence(int Absence) {
        this.Absence = Absence;
    }

    public int getAttendInAnotherTime() {
        return AttendInAnotherTime;
    }

    public void setAttendInAnotherTime(int AttendInAnotherTime) {
        this.AttendInAnotherTime = AttendInAnotherTime;
    }

    public double getTotalMoney() {
        return TotalMoney;
    }

   

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public int getId() {
        return id;
    }

    public double getPayment() {
        return payment;
    }

    public void setPayment(double payment) {
        this.payment = payment;
    }

    public String getNotes() {
        return Notes;
    }

    public void setNotes(String Notes) {
        this.Notes = Notes;
    }

    public int getTotalNumber() {
        return TotalNumber;
    }

    public void setTotalNumber(int totalStudent) {
        this.TotalNumber = totalStudent;
    }

    public int getTotalDegree() {
        return totalDegree;
    }

   

    public void setTotalMoney(double TotalMoney) {
        this.TotalMoney = TotalMoney;
    }

    public void setTotalDegree(int totalDegree) {
        this.totalDegree = totalDegree;
    }

    public double getStudentDegree() {
        return studentDegree;
    }

    public void setStudentDegree(double studentDegree) {
        this.studentDegree = studentDegree;
    }

    

    public double getIncreaseBalance() {
        return increaseBalance;
    }

    public void setIncreaseBalance(double increaseBalance) {
        this.increaseBalance = increaseBalance;
    }
    
}
